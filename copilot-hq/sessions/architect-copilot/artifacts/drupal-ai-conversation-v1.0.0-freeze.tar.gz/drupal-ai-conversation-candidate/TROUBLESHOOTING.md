# AI Conversation Module - Troubleshooting Guide

**Module:** AI Conversation for Drupal

**Version:** 1.0.0

## Quick Diagnostics

Before troubleshooting, verify basic setup:

```bash
# Check module status
drush pm:list | grep ai_conversation

# Check Drupal logs
drush watchdog:show --type=ai_conversation --limit=50

# Verify configuration
drush config:get ai_conversation.settings

# Test database connection
drush sql:query "SELECT * FROM node_field_data WHERE type='ai_conversation';"

# List available memory and disk
df -h /
free -h
```

## Installation Problems

### Module Won't Enable

**Symptom:** `drush en ai_conversation` fails with error

**Diagnosis:**

1. Check dependency errors:
```bash
drush pm:list --status=uninstalled
```

2. Verify composer dependencies:
```bash
composer require forseti-life/drupal-ai-conversation
```

3. Check PHP version:
```bash
php -v
# Requires PHP 8.1+
```

4. Check Drupal version:
```bash
drush status
# Requires Drupal 9, 10, or 11
```

**Solution:**

If dependencies missing:
```bash
composer update
drush cr
```

If PHP version too old:
- Upgrade PHP to 8.1 or later

If Drupal version incompatible:
- Upgrade Drupal to 9, 10, or 11

### Database Errors During Install

**Symptom:** "Exception: SQLSTATE[42000]..." during `drush updb`

**Cause:** Field definitions conflict or missing base tables

**Solution:**

1. Check for existing tables:
```bash
drush sql:query "SHOW TABLES LIKE 'ai_%';"
```

2. If tables exist from failed install, drop them:
```bash
drush sql:query "DROP TABLE IF EXISTS storage_ai_conversation_messages;"
```

3. Re-run updates:
```bash
drush updb -y
```

4. If still failing, reinstall module:
```bash
drush pm:uninstall ai_conversation -y
drush pm:install ai_conversation -y
```

## Configuration Problems

### AWS Credentials Not Working

**Symptom:** "InvalidSignatureException" or "UnrecognizedClientException"

**Diagnosis:**

1. Check credentials are set:
```bash
echo $AWS_ACCESS_KEY_ID
echo $AWS_DEFAULT_REGION
```

2. Verify credentials in Drupal config:
```bash
drush config:get ai_conversation.settings | grep aws
```

3. Test AWS CLI (if installed):
```bash
aws bedrock list-foundation-models --region us-east-1
```

**Solution:**

1. Set environment variables:
```bash
export AWS_ACCESS_KEY_ID="AKIA..."
export AWS_SECRET_ACCESS_KEY="..."
export AWS_DEFAULT_REGION="us-east-1"
```

2. Restart web server:
```bash
systemctl restart apache2
# or
systemctl restart nginx
```

3. Verify IAM policy allows Bedrock:

Go to AWS Console → IAM → Users → Select User → Add inline policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "bedrock:InvokeModel",
      "Resource": "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-*"
    }
  ]
}
```

4. Clear Drupal cache:
```bash
drush cr
```

### Ollama Connection Refused

**Symptom:** "ConnectionException: Connection refused" or "curl error"

**Diagnosis:**

1. Check if Ollama is running:
```bash
curl http://localhost:11434/api/tags
```

2. Check Ollama logs:
```bash
journalctl -u ollama -n 50
# or check docker logs if running in container
docker logs ollama
```

3. Verify base URL in Drupal:
```bash
drush config:get ai_conversation.settings | grep ollama_base_url
```

**Solution:**

1. Start Ollama:
```bash
# If installed locally:
ollama serve

# If Docker:
docker run -d -p 11434:11434 ollama/ollama
```

2. Verify Ollama is accessible:
```bash
curl -v http://localhost:11434/api/tags
```

3. Update base URL if necessary:
```bash
drush config:set ai_conversation.settings ollama_base_url "http://actual-ollama-host:11434"
```

4. Verify firewall allows port 11434:
```bash
sudo ufw allow 11434/tcp
# or
sudo firewall-cmd --add-port=11434/tcp
```

5. Verify model is pulled:
```bash
ollama list
# If model missing, pull it:
ollama pull neural-chat
```

### Model Not Available

**Symptom:** "Model not available" dropdown or "ValidationException: Model not found"

**Diagnosis:**

1. List available models in AWS:
```bash
aws bedrock list-foundation-models --region us-east-1 | grep anthropic
```

2. List models available in Ollama:
```bash
ollama list
```

3. Check configured model in Drupal:
```bash
drush config:get ai_conversation.settings | grep model
```

**Solution:**

For AWS Bedrock:

1. Verify region supports Claude:
```bash
aws bedrock list-foundation-models --region us-east-1
```

2. If empty, try different region (Claude available in limited regions):
```bash
aws bedrock list-foundation-models --region us-west-2
drush config:set ai_conversation.settings bedrock_region "us-west-2"
```

For Ollama:

1. Pull the model:
```bash
ollama pull neural-chat
```

2. Select model in Drupal admin settings

3. Verify model is loaded:
```bash
curl http://localhost:11434/api/tags
```

## Runtime Problems

### Conversations Not Loading

**Symptom:** Chat page shows blank or "Node not found"

**Diagnosis:**

1. Verify conversation exists:
```bash
drush entity:load node 123
# (replace 123 with actual node ID)
```

2. Check user has permission:
```bash
drush user:role:add ai_user admin
drush user-list-permissions admin | grep ai_conversation
```

3. Verify content type exists:
```bash
drush config:get node.type.ai_conversation
```

**Solution:**

1. Verify node is published:
```bash
drush sql:query "SELECT nid, status FROM node_field_data WHERE type='ai_conversation';"
```

2. Grant permission to user:
```bash
drush role:add-permission authenticated "use ai conversation"
```

3. Clear cache:
```bash
drush cr
```

### Chat Interface Doesn't Work

**Symptom:** Messages not sending or no responses

**Diagnosis:**

1. Check browser console for JavaScript errors (F12)

2. Check Drupal logs:
```bash
drush watchdog:show --type=ai_conversation
```

3. Verify AJAX permissions:
```bash
drush role:add-permission authenticated "access content"
```

4. Check provider credentials:
```bash
drush config:get ai_conversation.settings
```

**Solution:**

1. Enable AJAX error logging:
```bash
drush config:set system.performance js.preprocess 0
drush cr
```

2. Check browser Network tab for 403/500 errors

3. Verify user has permission:
```bash
drush user:role:add authenticated ai_user
```

4. Verify provider credentials are set (see AWS/Ollama setup above)

5. Check conversation can be loaded:
```bash
drush entity:load node 123
```

### "Out of Memory" or "Timeout" Errors

**Symptom:** Large conversations fail or become slow

**Diagnosis:**

1. Check server memory:
```bash
free -h
ps aux | sort -nrk 3,3 | head -10
```

2. Check max_execution_time:
```bash
php -i | grep max_execution_time
```

3. Check available disk:
```bash
df -h
```

**Solution:**

1. Increase PHP memory limit in php.ini:
```ini
memory_limit = 512M
max_execution_time = 300
```

2. Enable summarization to compress old messages:
```bash
drush config:set ai_conversation.settings enable_summarization true
drush config:set ai_conversation.settings summary_threshold 10
```

3. Archive old conversations to separate storage

4. Increase message retrieval timeout:
```bash
drush config:set ai_conversation.settings api_timeout 30
```

5. Verify disk space:
```bash
df -h
du -sh /var/www/drupal
```

### "Suggestion" Errors

**Symptom:** Community suggestions not being saved

**Diagnosis:**

1. Verify content type exists:
```bash
drush config:get node.type.community_suggestion
```

2. Check user has permission:
```bash
drush user:role:add authenticated "create community_suggestion content"
```

3. Check logs:
```bash
drush watchdog:show --type=ai_conversation
```

**Solution:**

1. Create community_suggestion content type if missing:
```bash
drush generate plugin-manager ai-provider
# Then manually create node type via admin UI
```

2. Grant permission:
```bash
drush role:add-permission authenticated "create community_suggestion content"
```

3. Verify conversation node has reference field:
```bash
drush config:get field.field.node.ai_conversation.field_conversation_ref
```

## Performance Troubleshooting

### API Calls Are Slow

**Symptom:** Responses take >10 seconds

**Diagnosis:**

1. Check provider API status:
```bash
# AWS: Check CloudWatch in AWS Console
# Ollama: Check if model is loaded in GPU
ollama ps
```

2. Check network connectivity:
```bash
ping api.bedrock.us-east-1.amazonaws.com
curl -w "@curl-format.txt" -o /dev/null -s http://localhost:11434/api/tags
```

3. Check message history size:
```bash
# In Drupal, check number of messages in conversation
drush entity:load node 123 | grep field_ai_messages
```

**Solution:**

1. For AWS: Check if model is throttled or account has limits

2. For Ollama: 
   - Load model to GPU: `ollama run neural-chat`
   - Check GPU memory: `nvidia-smi`

3. Enable summarization to reduce context size:
```bash
drush config:set ai_conversation.settings enable_summarization true
```

4. Reduce max_context_tokens:
```bash
drush config:set ai_conversation.settings max_context_tokens 50000
```

5. Check database query performance:
```bash
mysql -u drupal_user -p drupal_db
EXPLAIN SELECT * FROM node_field_data WHERE type='ai_conversation'\G
```

### High API Costs

**Symptom:** Unexpected AWS charges or high token usage

**Diagnosis:**

1. Check token usage:
```bash
drush watchdog:show --type=ai_conversation | grep tokens
```

2. Verify model is efficient:
```bash
drush config:get ai_conversation.settings | grep model
```

3. Check if conversations are re-sending full history:
```bash
# Review logs for repeated API calls
drush watchdog:show --severity=notice --type=ai_conversation
```

**Solution:**

1. Enable summarization:
```bash
drush config:set ai_conversation.settings enable_summarization true
```

2. Use cheaper model:
```bash
# Change from Claude Sonnet to Haiku
drush config:set ai_conversation.settings model "us.anthropic.claude-haiku-4-5"
```

3. Set token limits:
```bash
drush config:set ai_conversation.settings max_response_tokens 1024
```

4. Reduce context window:
```bash
drush config:set ai_conversation.settings max_context_tokens 32000
```

## Getting Help

If troubleshooting doesn't resolve the issue:

1. **Check module logs:**
```bash
drush watchdog:show --type=ai_conversation --limit=100
```

2. **Enable debug mode** (if available):
```bash
drush config:set ai_conversation.settings debug_mode true
drush cr
```

3. **Report issue on GitHub:**
   - https://github.com/Forseti-Life/drupal-ai-conversation/issues

4. **Include in bug report:**
   - Drupal version: `drush status`
   - PHP version: `php -v`
   - Module version: `drush pm:list | grep ai_conversation`
   - Error message from: `drush watchdog:show --type=ai_conversation`
   - Steps to reproduce
   - Expected behavior vs actual behavior

5. **For security issues:**
   See SECURITY.md for responsible disclosure process

---

**Still stuck?** See README.md for links to community resources.
