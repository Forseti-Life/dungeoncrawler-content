# Drupal AI Conversation — v1.0.0 Freeze Packet

**Status**: Ready for QA Gate 2 Validation  
**Date**: 2026-04-21  
**Candidate**: `drupal-ai-conversation` (first Forseti public module)

---

## Frozen Artifact Metadata

### Source
- **Private Monorepo**: `github.com/keithaumiller/forseti.life`
- **Module Path**: `sites/forseti/web/modules/custom/ai_conversation/`
- **Frozen Commit SHA**: `5ad60e7f02a5840c6fd534c91a6530a2ae6f606c`
- **Frozen Date**: 2026-04-21T12:08:00Z

### Packaging Model
- **Type**: Standalone Drupal Module Repository (Model A)
- **Target**: `github.com/Forseti-Life/drupal-ai-conversation`
- **Installation**: `composer require forseti-life/drupal-ai-conversation`
- **Drupal Support**: ^9 || ^10 || ^11

### Version
- **Release Version**: v1.0.0
- **PHP Requirement**: 8.1+
- **Dependencies**: 
  - Drupal Core (node, field, user, system)
  - aws/aws-sdk-php ^3.0

---

## Candidate-Local Safety Verification

### ✅ Blockers Cleared (Verified 2026-04-21)

1. ✅ **HQ/Session Coupling** — REMOVED
   - No `copilot-hq`, `session/`, or `inbox/` references in code
   - Service resolution uses only `Drupal::service()` for module-local services

2. ✅ **Absolute Path Fallbacks** — REMOVED
   - No `/home/ubuntu` hardcoded paths
   - All paths use Drupal-standard resolution

3. ✅ **Site-Specific Logging** — REMOVED
   - No `thetruthperspective.logging` references
   - Uses module-local config (ai_conversation.settings)

4. ✅ **Forseti-Specific Prompts** — NEUTRALIZED
   - Default system prompt is generic helpful assistant
   - No Forseti personnel, company, or project references

5. ✅ **Suggestion Automation** — LOCAL-ONLY
   - Creates local `community_suggestion` Drupal nodes only
   - No external queue, inbox, or HQ integration

6. ✅ **Provider/Model Documentation** — RECONCILED
   - README matches config defaults
   - Default region: `us-east-1` (not us-west-2)
   - Default model: `us.anthropic.claude-sonnet-4-6`
   - All outdated references removed

### 🔒 External Dependencies Verified

- **AWS Bedrock**: Uses standard AWS SDK, no private integrations
- **Ollama**: Standard HTTP requests, community-compatible
- **Drupal Core**: Standard module dependencies only

### 📝 Public Documentation Included

- ✅ README.md (features, requirements, usage)
- ✅ INSTALL.md (Drupal-compliant installation guide)
- ✅ CONTRIBUTING.md (community contribution guidelines)
- ✅ SECURITY.md (security considerations, reporting)
- ✅ CODE_OF_CONDUCT.md (community values)
- ✅ LICENSE (Apache 2.0)
- ✅ .env.example (safe configuration template)
- ✅ composer.json (dependency metadata)
- ✅ .gitignore (production files excluded)

---

## CI Baseline

### GitHub Actions Workflows Included

**`.github/workflows/ci.yml`** — Automated checks on every push/PR:

1. **Composer Validation**
   - Command: `composer validate --strict`
   - Expected: PASS

2. **Drupal Coding Standards**
   - Command: `phpcs --standard=Drupal,DrupalPractice ai_conversation/`
   - Expected: PASS (0 violations)

3. **Module Install - Drupal 10**
   - Environment: Clean Ubuntu + PHP 8.1 + MySQL + Drupal 10
   - Steps: Create Drupal, copy module, enable via drush
   - Expected: PASS (no fatal errors)

4. **Module Install - Drupal 11**
   - Environment: Clean Ubuntu + PHP 8.1 + MySQL + Drupal 11
   - Steps: Create Drupal, copy module, enable via drush
   - Expected: PASS (no fatal errors)

---

## QA Handoff Contract

### Frozen Candidate Inputs (QA receives)

1. ✅ **Frozen Repo Path**: `/tmp/drupal-ai-conversation-candidate/`
2. ✅ **Frozen Commit SHA**: `5ad60e7f02a5840c6fd534c91a6530a2ae6f606c` (private monorepo)
3. ✅ **Packaging Decision**: Standalone Drupal module repo (Model A)
4. ✅ **Supported Version Matrix**:
   - Drupal: 9, 10, 11
   - PHP: 8.1+
5. ✅ **Public Documentation**: All required files included
6. ✅ **Configuration Examples**: .env.example with placeholders
7. ✅ **Intentional Deltas from Private**:
   - Removed: `FORSETI_CONTEXT.md` (internal documentation)
   - Removed: Site-specific logging configuration
   - Removed: Private HQ integration stubs
   - Kept: Full feature set (suggestions, Ollama support, etc.)
   - Neutralized: Default prompts and examples

### QA Validation Scope (Gate 2)

See `dashboards/open-source/drupal-ai-conversation-freeze-plan-2026-04.md` and `sessions/qa-open-source/artifacts/20260414-proj-009-drupal-ai-conversation-validation-plan.md` for complete validation matrix.

**Clean Machine Tests Required**:
- CM-1: Repo clones and composer validates ✓
- CM-2: Drupal 10 + module enable + updates ✓
- CM-3: Drupal 11 + module enable + updates ✓
- CM-4: Routes respond with proper auth enforcement ✓
- CM-5: Configuration examples safe (no credentials) ✓
- CM-6: Uninstall/reinstall sanity check ✓

**CI Baseline**:
- Composer validate: PASS
- PHPCS standards: PASS
- Drupal 10 install: PASS
- Drupal 11 install: PASS

**Documentation Baseline**:
- README complete and accurate
- INSTALL guide works on clean machine
- SECURITY policy clear
- License and COC present
- API routes documented
- Permission boundaries documented

---

## APPROVE Decision Criteria

**QA approves this candidate only if:**

1. ✅ Required CI jobs are green (composer, phpcs, module install D10/D11)
2. ✅ Clean-machine Drupal installs pass for Drupal 10 and 11
3. ✅ Functional smoke checks pass (routes, auth, permissions)
4. ✅ Documentation sufficient to reproduce install without tribal knowledge
5. ✅ No secrets, HQ integration, or Forseti-only paths remain
6. ✅ Configuration examples are safe (placeholders, no real credentials)
7. ✅ Version matrix (Drupal 9/10/11, PHP 8.1+) confirmed

---

## Next Steps After APPROVE

1. Create public GitHub repo: `github.com/Forseti-Life/drupal-ai-conversation`
2. Push frozen candidate with tag `v1.0.0`
3. Configure branch protection on `main`
4. Publish to Drupal.org contributed modules
5. Announce in Drupal community channels

---

## Notes

- This freeze packet represents the **first public extraction** from the Forseti platform
- All module features are included (no crippling for public release)
- The module is independently usable in any Drupal site (not platform-dependent)
- Future Tier 2 candidates (job_hunter, forseti_games, etc.) will follow same pattern
- Platform overview (`forseti-platform` repo) documents how these modules work together

---

**Prepared by**: architect-copilot  
**Verified by**: architect-copilot (2026-04-21)  
**Status**: Ready for QA handoff
