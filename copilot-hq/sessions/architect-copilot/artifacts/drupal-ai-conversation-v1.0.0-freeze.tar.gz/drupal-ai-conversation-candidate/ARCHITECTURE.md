# AI Conversation Module - Architecture & API Reference

**Module:** AI Conversation for Drupal

**Version:** 1.0.0

**Last Updated:** April 2026

## Table of Contents

- [Overview](#overview)
- [Core Concepts](#core-concepts)
- [Conversation Lifecycle](#conversation-lifecycle)
- [API Reference](#api-reference)
- [Service Architecture](#service-architecture)
- [Configuration](#configuration)
- [Data Model](#data-model)
- [Hooks & Extensibility](#hooks--extensibility)
- [Performance Considerations](#performance-considerations)

## Overview

The AI Conversation module is built around three core concepts:

1. **Conversations as Nodes:** Conversations are Drupal nodes, giving 
   them full CMS capabilities (permissions, workflow, versioning).

2. **Messages in Fields:** Messages are stored in a Drupal field, 
   making them queryable and manageable through standard Drupal tools.

3. **Provider Abstraction:** The module abstracts away provider 
   differences (AWS Bedrock vs Ollama), allowing providers to be 
   swapped without code changes.

## Core Concepts

### Conversation Node

A conversation node represents a chat session:

```
ai_conversation node {
  title: string         (conversation title)
  body: text            (conversation notes)
  messages: field_array (conversation history)
  summary: text         (auto-generated summary)
  ai_model: string      (selected model)
  system_prompt: text   (conversation persona)
}
```

### Message Structure

Messages are stored in the `field_ai_messages` field:

```
message {
  role: string          ("user" or "assistant")
  content: text         (message text)
  tokens_input: integer (input tokens used)
  tokens_output: integer (output tokens used)
  created: timestamp    (message timestamp)
  summary_id: integer   (reference to summary if compacted)
}
```

### Provider Abstraction

Providers implement the `AIProviderInterface`:

```php
interface AIProviderInterface {
  public function invoke(
    string $model,
    array $messages,
    int $max_tokens
  ): array;
  
  public function validateCredentials(): bool;
  
  public function listModels(): array;
}
```

Current implementations:
- `BedrockProvider`: AWS Bedrock API
- `OllamaProvider`: Self-hosted Ollama

## Conversation Lifecycle

### 1. Creation

User creates a new conversation node with optional custom system 
prompt:

```php
$conversation = Node::create([
  'type' => 'ai_conversation',
  'title' => $title,
  'ai_model' => 'us.anthropic.claude-sonnet-4-6',
  'system_prompt' => 'You are a helpful assistant...',
  'uid' => $user->id(),
  'status' => 1,
]);
$conversation->save();
```

### 2. Message Exchange

User sends a message via the API:

```php
POST /ai-conversation/send-message
{
  "nid": 123,
  "message": "What is machine learning?"
}
```

The AIApiService:
1. Loads the conversation node
2. Retrieves message history
3. Constructs message array for provider
4. Calls provider (AWS/Ollama)
5. Stores response as new message
6. Returns response to user

### 3. Summarization

When a conversation grows large:

1. Summarizer identifies old messages
2. Sends summary request to provider
3. Stores compact summary reference
4. Removes old messages
5. Future API calls use summary context

### 4. Cleanup

Users delete conversation nodes:

```php
$conversation->delete();
```

Related suggestions are orphaned (not auto-deleted).

## API Reference

### AIApiService

Main service for programmatic conversation management.

**Location:** `src/Service/AIApiService.php`

**Inject via:**
```php
$ai_service = \Drupal::service('ai_conversation.api_service');
```

#### Methods

##### sendMessage

Send a user message and get AI response.

```php
public function sendMessage(
  NodeInterface $conversation,
  string $user_message,
  int $user_id
): array
```

**Parameters:**
- `$conversation`: The conversation node entity
- `$user_message`: User's message text
- `$user_id`: Drupal user ID sending the message

**Returns:**
```php
[
  'success' => true|false,
  'message' => 'text response from AI',
  'tokens_input' => 156,
  'tokens_output' => 342,
  'error' => 'error message if !success'
]
```

**Example:**
```php
$ai = \Drupal::service('ai_conversation.api_service');
$result = $ai->sendMessage($node, 'Hello!', $user->id());
if ($result['success']) {
  $response = $result['message'];
}
```

##### getConversationHistory

Retrieve formatted message history for display or API calls.

```php
public function getConversationHistory(
  NodeInterface $conversation
): array
```

**Returns:**
```php
[
  [
    'role' => 'user',
    'content' => 'First user message'
  ],
  [
    'role' => 'assistant',
    'content' => 'Response'
  ],
  ...
]
```

##### createSuggestion

Record community suggestion/feedback during conversation.

```php
public function createSuggestion(
  NodeInterface $conversation,
  string $suggestion_text,
  int $user_id
): NodeInterface
```

**Parameters:**
- `$conversation`: Parent conversation node
- `$suggestion_text`: User's suggestion or feedback
- `$user_id`: Drupal user ID (can be anonymous)

**Returns:** The created suggestion node

**Example:**
```php
$ai->createSuggestion(
  $conversation,
  'AI could be more concise',
  \Drupal::currentUser()->id()
);
```

#### Configuration Methods

##### getAvailableModels

List models available for current provider.

```php
public function getAvailableModels(): array
```

**Returns:**
```php
[
  'us.anthropic.claude-sonnet-4-6' => 'Claude Sonnet 4.6',
  'us.anthropic.claude-haiku-4-5' => 'Claude Haiku 4.5',
]
```

##### getConfiguration

Retrieve current module configuration.

```php
public function getConfiguration(): ConfigInterface
```

### AIProviderInterface

Contract for AI provider implementations.

**Location:** `src/Provider/AIProviderInterface.php`

#### Required Methods

##### invoke

Send messages to AI model.

```php
public function invoke(
  string $model,
  array $messages,
  int $max_tokens = 1024
): array
```

**Parameters:**
- `$model`: Model identifier (e.g., 'claude-sonnet-4-6')
- `$messages`: Array of message objects with 'role' and 'content'
- `$max_tokens`: Maximum response tokens

**Returns:**
```php
[
  'text' => 'AI response text',
  'tokens_input' => 156,
  'tokens_output' => 342,
  'model' => 'model-used',
]
```

**Throws:**
- `ProviderException`: If API call fails

##### validateCredentials

Verify provider credentials are valid.

```php
public function validateCredentials(): bool
```

**Returns:** true if credentials work, false otherwise

##### listModels

Get available models for current credentials/region.

```php
public function listModels(): array
```

**Returns:**
```php
[
  'model-id' => 'Human Readable Name',
  ...
]
```

## Service Architecture

### Dependencies

The module uses these core Drupal services:

- `entity_type.manager`: Create/load nodes
- `config.factory`: Read configuration
- `current_user`: Get logged-in user
- `logger.channel.ai_conversation`: Log events
- `plugin.manager.ai_provider`: Load providers

### Provider Loading

Providers are loaded via plugin system:

```php
$provider_id = \Drupal::config('ai_conversation.settings')
  ->get('provider');
$provider = \Drupal::service('plugin.manager.ai_provider')
  ->createInstance($provider_id);
```

### Message Persistence

Messages are stored as field values:

```php
$conversation->field_ai_messages[] = [
  'role' => 'user',
  'content' => $message,
  'tokens_input' => 100,
  'tokens_output' => 150,
  'created' => \Drupal::time()->getRequestTime(),
];
$conversation->save();
```

## Configuration

### Settings File

Configuration stored in `ai_conversation.settings`:

```yaml
provider: 'bedrock'           # or 'ollama'
model: 'claude-sonnet-4-6'
bedrock_region: 'us-east-1'
ollama_base_url: 'http://localhost:11434'
max_context_tokens: 100000    # Total context window
max_response_tokens: 2048     # Max response size
enable_summarization: true
summary_threshold: 10         # Messages before summarizing
system_prompt_default: '...'  # Default system prompt
enable_suggestions: true
```

### Environment Variables

Credentials read from environment:

```
AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
AWS_DEFAULT_REGION
OLLAMA_BASE_URL (optional, default: http://localhost:11434)
```

### Permissions

- `use ai conversation`: Create and chat in conversations
- `administer ai conversation`: Configure settings
- `edit own ai conversation`: Edit own conversations
- `delete own ai conversation`: Delete own conversations

## Data Model

### Conversation Node

**Type:** `ai_conversation`

**Fields:**
- `title`: string (conversation title)
- `body`: text (notes about conversation)
- `field_ai_messages`: field_array (message history)
- `field_ai_model`: string (selected model)
- `field_system_prompt`: text (conversation persona)
- `uid`: integer (node owner)
- `status`: boolean (published/unpublished)
- `created`: timestamp
- `changed`: timestamp

### Suggestion Node

**Type:** `community_suggestion`

**Fields:**
- `title`: string (auto-generated from parent)
- `body`: text (the suggestion)
- `field_conversation_ref`: entity_reference (parent conversation)
- `uid`: integer (who submitted)
- `status`: boolean (published/unpublished)
- `created`: timestamp

### Message Array Structure

Each message in field_ai_messages:

```php
[
  'role' => 'user|assistant',
  'content' => 'message text',
  'tokens_input' => integer,
  'tokens_output' => integer,
  'created' => timestamp,
  'summary_id' => integer (if part of summary),
]
```

## Hooks & Extensibility

### hook_ai_conversation_message_create

Fired after a message is created.

```php
function mymodule_ai_conversation_message_create(
  NodeInterface $conversation,
  array $message
) {
  // React to new message
}
```

### hook_ai_conversation_response_alter

Alter AI response before storing.

```php
function mymodule_ai_conversation_response_alter(
  array &$response,
  NodeInterface $conversation,
  string $user_message
) {
  // Modify $response
}
```

### hook_ai_conversation_system_prompt_alter

Customize system prompt for specific conversations.

```php
function mymodule_ai_conversation_system_prompt_alter(
  string &$prompt,
  NodeInterface $conversation
) {
  // Modify system prompt
}
```

## Performance Considerations

### Database

- Messages are stored as field values (not separate table)
- Use Views to query/filter conversations by various criteria
- Consider indexing `created` and `uid` fields for large datasets

### API Calls

- Each message sends all context to provider (per conversation history)
- Use summarization to keep context windows manageable
- Consider token budgets to avoid runaway costs

### Caching

- Module cache tags:
  - `ai_conversation:conversation:NID`
  - `ai_conversation:messages:NID`
- Drupal's cache is cleared when conversation saved
- For high-volume sites, consider Redis backend

### Scaling

For sites with many conversations:

1. Use field indexing on created/uid
2. Implement archive strategy (move old conversations to cold storage)
3. Monitor API usage and set token budgets
4. Consider separating read/write paths for reporting

## Example: Custom Provider

Implement a custom AI provider:

```php
namespace Drupal\mymodule\Plugin\AIProvider;

use Drupal\ai_conversation\Plugin\AIProviderBase;

/**
 * My Custom Provider
 * 
 * @AIProvider(
 *   id = "mycustom",
 *   label = @Translation("My Custom API")
 * )
 */
class MyCustomProvider extends AIProviderBase {

  public function invoke(
    string $model,
    array $messages,
    int $max_tokens = 1024
  ): array {
    // Call your custom API
    $response = $this->callMyAPI($model, $messages);
    return [
      'text' => $response['content'],
      'tokens_input' => $response['input_tokens'],
      'tokens_output' => $response['output_tokens'],
      'model' => $model,
    ];
  }

  public function validateCredentials(): bool {
    // Test connection
    return $this->callMyAPI('test', []) !== false;
  }

  public function listModels(): array {
    return [
      'mycustom-model-1' => 'My Model 1',
      'mycustom-model-2' => 'My Model 2',
    ];
  }
}
```

---

For more information, see README.md for user documentation and 
CONTRIBUTING.md for development guidelines.
