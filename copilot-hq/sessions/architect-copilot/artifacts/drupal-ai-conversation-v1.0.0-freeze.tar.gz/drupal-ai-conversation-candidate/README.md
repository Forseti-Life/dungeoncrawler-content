# AI Conversation Module

**Module:** AI Conversation for Drupal

**Version:** 1.0.0

**Maintained by:** Forseti Life <https://github.com/Forseti-Life/>

## Overview

The AI Conversation module provides persistent AI-powered conversations 
with context management, rolling summarization, and support for multiple 
AI providers. Conversations are stored as Drupal content nodes, offering 
full integration with Drupal's permission system, user management, and 
content workflows.

This module is production-ready for sites that need conversational AI 
capabilities with AWS Bedrock (managed AI) or self-hosted Ollama support.

## Requirements

- **Drupal:** 9, 10, or 11
- **PHP:** 8.1 or later
- **Node module:** For conversation storage
- **Field module:** For structured message storage
- **User module:** For permission management
- **System module:** Core functionality
- **AWS Bedrock** (if using managed AI): Valid AWS credentials with 
  Bedrock API access
- **Ollama** (if using self-hosted): Accessible Ollama instance with 
  configured models

## Installation

### 1. Install via Composer (Recommended)

From your Drupal root directory:

```
composer require forseti-life/drupal-ai-conversation
```

### 2. Enable the Module

```
drush en ai_conversation -y
```

### 3. Run Database Updates

```
drush updb -y
```

### 4. Clear Caches

```
drush cr
```

The module will display a confirmation message with a link to 
configuration settings.

## Configuration

### Environment Setup

Set credentials before enabling the module:

```
export AWS_ACCESS_KEY_ID="your_key_id"
export AWS_SECRET_ACCESS_KEY="your_secret_key"
export AWS_DEFAULT_REGION="us-east-1"
```

Or use `.env` file (see `.env.example`).

### Admin Configuration

Navigate to `/admin/config/ai-conversation/settings`:

1. **Provider:** Select AWS Bedrock or Ollama
2. **Model:** Choose available AI model
3. **Region** (Bedrock only): AWS region
4. **Token Limits:** Configure per-response budgets
5. **Summarization:** Set frequency and retention

### Permissions

Navigate to `/admin/people/permissions`:

- **Use AI Conversation:** Create and chat in conversations
- **Administer AI Conversation:** Configure settings and view reports

## Quick Start

### Create a Conversation

1. Navigate to **Content > Add Content > AI Conversation**
2. Enter a title (e.g., "Project Discussion")
3. Optionally customize the system prompt
4. Save the node

### Start Chatting

1. View the conversation node you just created
2. Click **"Start Chat"** or navigate to `/node/{nid}/chat`
3. Type a message and press Send
4. AI responds within seconds

### Monitor Usage

Navigate to `/admin/reports/ai-conversation/stats` to view:
- Token usage per conversation
- Message counts
- Summary status
- Recent activity

## Features

### Persistent Storage
Conversations are stored as Drupal nodes, fully under your control. 
No data is sent to Forseti infrastructure—only to your configured 
AI provider (AWS or Ollama).

### Multiple AI Providers
- **AWS Bedrock:** Managed Claude models (cost, quality, speed)
- **Ollama:** Self-hosted open-source models (privacy, control)

### Intelligent Summarization
Automatic rolling summaries keep conversations efficient:
- Recent messages preserved in full
- Older messages compacted into summaries
- Configurable frequency and retention

### Token Tracking
Monitor and optimize AI costs:
- Input/output tokens per message
- Total tokens per conversation
- Configurable limits and alerts

### Permission-Based Access
- Uses Drupal's permission system
- Users can only access their own conversations
- Admin can view all conversations and reports

### Community Feedback
Users can submit suggestions and feedback during conversations, 
captured as community_suggestion nodes for site admin review.

## Usage Patterns

### Administrative Use
- Configure AI models and behavior
- Monitor system usage and costs
- Review community suggestions

### End-User Chat
- Create conversations for specific topics
- Chat naturally with AI assistant
- Reference conversation history
- Submit feedback and suggestions

### Custom Integration
Use the AIApiService for programmatic access:

```php
$ai_service = \Drupal::service('ai_conversation.api_service');
$response = $ai_service->sendMessage($conversation_node, 
  $user_message, $user_id);
```

See ARCHITECTURE.md for full API documentation.

## API Routes

- `GET /node/{nid}/chat`
  Chat interface for conversation (requires "use ai conversation" 
  permission)

- `POST /ai-conversation/send-message`
  Send message to conversation (AJAX, requires permission and CSRF)

- `GET /admin/config/ai-conversation/settings`
  Module settings (requires admin permission)

- `GET /admin/reports/ai-conversation/stats`
  Usage statistics (requires admin permission)

## AWS Bedrock Setup

### 1. Create IAM User

In AWS Console:
1. Navigate to **IAM > Users > Create User**
2. Enable **Programmatic Access**
3. Attach policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "bedrock:InvokeModel",
      "Resource": "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-*"
    }
  ]
}
```

4. Copy Access Key ID and Secret Access Key

### 2. Configure Module

Set environment variables:

```
export AWS_ACCESS_KEY_ID="AKIA..."
export AWS_SECRET_ACCESS_KEY="..."
export AWS_DEFAULT_REGION="us-east-1"
```

Then configure in Drupal admin interface.

### 3. Supported Models

- `us.anthropic.claude-sonnet-4-6` (default, recommended)
- `us.anthropic.claude-haiku-4-5` (faster, cheaper)
- `us.anthropic.claude-3-5-haiku-20241022-v1:0` (legacy)

## Ollama Setup

### 1. Install Ollama

Download from https://ollama.ai or install via package manager:

```
sudo apt-get install ollama
```

### 2. Start Ollama Server

```
ollama serve
```

In another terminal, pull a model:

```
ollama pull claude
```

### 3. Configure Module

1. Go to `/admin/config/ai-conversation/settings`
2. Select **Ollama** as provider
3. Enter base URL: `http://localhost:11434`
4. Select model from dropdown

## Frequently Asked Questions

### Q: Where is my conversation data stored?
A: Conversations are Drupal nodes in your database. They are never 
sent to Forseti infrastructure. Only API calls to your configured 
AI provider (AWS Bedrock or Ollama) leave your server.

### Q: Can I export conversations?
A: Yes. Conversations are standard Drupal nodes. Use Drupal's content 
export functionality to export conversations with Views or custom 
modules.

### Q: What if I run out of tokens?
A: Configure token limits in module settings. The system will stop 
responding when limits are reached. Increase limits or reset usage as 
needed.

### Q: How do I delete conversations?
A: Delete nodes like any other Drupal content. Navigate to the 
conversation node and click **Delete**. Suggestions linked to that 
conversation will remain.

### Q: Can multiple users chat in the same conversation?
A: Currently, users can only see their own conversations. 
Multi-user conversation support may be added in future versions.

### Q: Is this GDPR compliant?
A: Conversations are stored locally. Ensure your AI provider (AWS or 
Ollama) complies with your jurisdiction's data protection 
requirements. Review SECURITY.md for important privacy considerations.

## Troubleshooting

### Module won't enable

Check logs:
```
drush watchdog:show
```

Verify dependencies are installed:
```
composer update
```

Clear Drupal cache:
```
drush cr
```

### AWS credentials not working

Verify environment variables:
```
echo $AWS_ACCESS_KEY_ID
```

Check IAM policy grants Bedrock access:
```
aws bedrock list-foundation-models --region us-east-1
```

Review error logs:
```
drush watchdog:show --type=ai_conversation
```

### Ollama connection refused

Verify Ollama is running:
```
curl http://localhost:11434/api/tags
```

Check firewall allows connection to Ollama port.

Verify base URL in module settings matches Ollama server address.

### Conversations not loading

Clear Drupal cache:
```
drush cr
```

Verify user has "use ai conversation" permission:
```
drush user:role:add ai_user admin
```

Check conversation node still exists and is published.

### "Model not available" errors

Verify model is available in configured region:
```
aws bedrock list-foundation-models --region us-east-1
```

For Ollama, verify model is pulled:
```
ollama list
```

### Suggestions not capturing

Verify `community_suggestion` content type is enabled and user has 
permission to create nodes.

Check module logs:
```
drush watchdog:show --type=ai_conversation
```

## Uninstall

### 1. Disable Module

```
drush dis ai_conversation -y
```

### 2. Uninstall (removes database tables)

```
drush pm:uninstall ai_conversation -y
```

### 3. Remove from Composer

```
composer remove forseti-life/drupal-ai-conversation
```

**Note:** Uninstalling removes the ai_conversation content type. 
Exported conversations will be deleted. Export data before 
uninstalling if you need to preserve conversations.

## Contributing

See CONTRIBUTING.md for guidelines on reporting bugs, suggesting 
features, and submitting pull requests.

## Security

See SECURITY.md for:
- Security vulnerability reporting
- Credential management best practices
- Important privacy and deployment considerations

## License

Licensed under Apache License 2.0. See LICENSE file for details.

## Support & Community

- **Issues:** 
  https://github.com/Forseti-Life/drupal-ai-conversation/issues
- **Discussions:** GitHub Discussions on project repository
- **Code:** https://github.com/Forseti-Life/drupal-ai-conversation

## Resources

- **Architecture Documentation:** See ARCHITECTURE.md in module
- **Installation Guide:** See INSTALL.md
- **Contributing Guide:** See CONTRIBUTING.md
- **Security Policy:** See SECURITY.md
- **Code of Conduct:** See CODE_OF_CONDUCT.md

## Related Projects

For other AI integration modules and frameworks:
- Visit https://drupal.org to search for AI and ML modules
- Check https://github.com/Forseti-Life for related projects

---

Built with ❤️ by the Forseti Life team.

Making autonomous development platforms accessible to everyone.
