# Installation Guide for Drupal AI Conversation

## Quick Start

### Prerequisites
- Drupal 10 or 11
- PHP 8.1+
- Composer
- AWS Bedrock credentials (for Bedrock provider) OR Ollama server (for self-hosted)

### Installation via Composer

```bash
# From your Drupal root directory
composer require forseti-life/drupal-ai-conversation

# Enable the module
drush en ai_conversation

# Run database updates
drush updb

# Clear caches
drush cr
```

## Configuration

### Step 1: Set Credentials

**Option A: Environment Variables (Recommended)**
```bash
export AWS_ACCESS_KEY_ID="your_key"
export AWS_SECRET_ACCESS_KEY="your_secret"
export AWS_DEFAULT_REGION="us-east-1"
```

**Option B: Drupal Settings File**
Add to `sites/default/settings.php`:
```php
$_ENV['AWS_ACCESS_KEY_ID'] = 'your_key';
$_ENV['AWS_SECRET_ACCESS_KEY'] = 'your_secret';
$_ENV['AWS_DEFAULT_REGION'] = 'us-east-1';
```

### Step 2: Configure Module

Navigate to `/admin/config/ai-conversation/settings`:

1. **Provider**: Select "AWS Bedrock" or "Ollama"
2. **Model**: Choose from available models
3. **Region** (Bedrock only): Select AWS region
4. **Token Limits**: Configure token budgets
5. **Summarization**: Set frequency and message retention

### Step 3: Set Permissions

Navigate to `/admin/people/permissions`:

1. Search for "ai_conversation"
2. Assign "Use AI Conversation" to appropriate roles
3. Assign "Administer AI Conversation" to admins only

### Step 4: Create Conversations

Navigate to **Content → Add Content → AI Conversation**:

1. Enter a title
2. Optionally customize system prompt
3. Save node
4. Click "Start Chat" to begin

## AWS Bedrock Setup

### Create IAM User

1. Go to AWS Console → IAM
2. Create new user with programmatic access
3. Attach policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "bedrock:InvokeModel",
      "Resource": "arn:aws:bedrock:us-east-1::foundation-model/anthropic.claude-*"
    }
  ]
}
```

### Supported Models

- `us.anthropic.claude-sonnet-4-6` (default, recommended)
- `us.anthropic.claude-haiku-4-5` (faster, cheaper)
- `us.anthropic.claude-3-5-haiku-20241022-v1:0` (legacy)

### Check Model Availability

```bash
aws bedrock list-foundation-models --region us-east-1
```

## Ollama Setup

### Install Ollama

1. Download from [ollama.ai](https://ollama.ai)
2. Run: `ollama serve`
3. In another terminal: `ollama pull claude` (or model of choice)

### Configure Module

1. Go to `/admin/config/ai-conversation/settings`
2. Select "Ollama" provider
3. Enter base URL: `http://localhost:11434` (or your Ollama server)
4. Select available model from dropdown

## Uninstall

```bash
# Disable module
drush dis ai_conversation

# Uninstall module (removes database tables)
drush pm:uninstall ai_conversation

# Remove from composer
composer remove forseti-life/drupal-ai-conversation
```

## Troubleshooting

### Module won't enable
- Check `drush watchdog:show` for errors
- Verify all dependencies installed: `composer update`
- Clear cache: `drush cr`

### AWS credentials not working
- Verify environment variables: `echo $AWS_ACCESS_KEY_ID`
- Check IAM policy includes Bedrock access
- Confirm region has Claude models available
- Review error logs: `/admin/reports/dblog`

### Ollama connection refused
- Verify Ollama is running: `curl http://localhost:11434/api/tags`
- Check firewall allows connection
- Verify base URL in module settings

### Conversations not loading
- Clear Drupal cache: `drush cr`
- Check node permissions
- Verify user has "use ai conversation" permission

## Next Steps

- See [README.md](README.md) for usage
- See [SECURITY.md](SECURITY.md) for security considerations
- See [ARCHITECTURE.md](ai_conversation/ARCHITECTURE.md) for technical details

## Support

- Issues: https://github.com/Forseti-Life/drupal-ai-conversation/issues
- Questions: Open a GitHub discussion
