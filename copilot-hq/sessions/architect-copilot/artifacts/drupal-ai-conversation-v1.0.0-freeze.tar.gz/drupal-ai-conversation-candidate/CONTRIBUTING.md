# Contributing to Drupal AI Conversation

Thank you for your interest in contributing to the Drupal AI Conversation module! We welcome contributions from the community.

## Getting Started

1. **Fork the repository** on GitHub
2. **Clone your fork** locally
3. **Create a feature branch** for your work
4. **Make your changes** with clear commit messages
5. **Push to your fork** and **submit a pull request**

## Code Style

This module follows Drupal coding standards:

```bash
# Install coding standards
composer install

# Check your code
./vendor/bin/phpcs --standard=Drupal,DrupalPractice ai_conversation/

# Fix automatically where possible
./vendor/bin/phpcbf --standard=Drupal,DrupalPractice ai_conversation/
```

## Testing

Please include tests for new functionality:

```bash
# Run module tests
cd drupal-root
php core/scripts/run-tests.sh --module ai_conversation
```

## Submitting Issues

- **Bug reports**: Include steps to reproduce, expected behavior, and actual behavior
- **Feature requests**: Describe the use case and desired behavior
- **Security issues**: Email security@forseti.life instead of using public issues

## PR Review Process

1. Automated checks must pass (coding standards, tests)
2. At least one maintainer review
3. All feedback addressed before merge
4. Clear, descriptive commit messages

## Branches

- `main` — Current stable release
- Feature branches for development

## License

By contributing, you agree that your contributions will be licensed under the Apache License 2.0.

## Questions?

Open a GitHub discussion or issue. We're here to help!

---

Built with ❤️ by the Forseti Life team.
