# Code of Conduct

## Our Pledge

We are committed to providing a welcoming and inspiring community for all. We pledge that everyone participating in the Drupal AI Conversation project and its community will be treated with respect and dignity.

## Our Standards

Examples of behavior that contribute to a positive environment:

- Using welcoming and inclusive language
- Being respectful of differing opinions and experiences
- Gracefully accepting constructive criticism
- Focusing on what is best for the community
- Showing empathy towards other community members

Examples of unacceptable behavior:

- Harassment or intimidation
- Discrimination based on any protected characteristic
- Offensive comments related to gender, race, religion, or other identity
- Personal attacks or trolling
- Unwelcome sexual attention
- Publishing others' private information without consent

## Enforcement

Instances of unacceptable behavior can be reported by:

- Commenting on the relevant issue or pull request
- Emailing conduct@forseti.life with details
- Contacting a project maintainer directly

All reports will be reviewed and investigated promptly and fairly. All community leaders are obligated to maintain confidentiality.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org), version 2.0.

---

Thank you for helping make this a welcoming, inclusive community!
