# Security Policy

## Reporting Security Vulnerabilities

If you discover a security vulnerability in the Drupal AI Conversation module, please report it responsibly:

1. **Do NOT** open a public issue on GitHub
2. **Email** security@forseti.life with:
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if you have one)

We will acknowledge receipt within 48 hours and work with you on a fix.

## Security Considerations

### Credential Management

- **Never commit credentials** to version control
- Always use **environment variables** for AWS credentials:
  ```bash
  export AWS_ACCESS_KEY_ID="your_key"
  export AWS_SECRET_ACCESS_KEY="your_secret"
  export AWS_DEFAULT_REGION="us-east-1"
  ```
- Use **IAM roles** when deployed on AWS infrastructure
- Rotate credentials regularly

### Permissions

- The module respects Drupal permission system
- Only users with `use ai conversation` permission can access conversations
- Ensure proper role/permission configuration per your site policies

### Data Privacy

- Conversations are stored as Drupal nodes — subject to your site's data retention policies
- User data is visible to conversation authors and site admins
- No data is sent to Forseti infrastructure (only to configured AI provider)
- AWS Bedrock request logs may be retained per AWS policy

### AI Model Behavior

- System prompts should not include sensitive information
- Users can view conversation history
- AI responses are not filtered by this module — review provider safety policies

## Dependencies

- **aws/aws-sdk-php**: Monitor for security updates via `composer update`
- **Drupal Core**: Keep up to date with security patches
- **PHP**: Use supported versions with active security updates

## Version Support

- Only the latest version receives security updates
- Older versions may receive critical fixes at maintainer discretion

---

For security questions or concerns, contact security@forseti.life
